#### 如果无法查看图片，可以访问：[Just My Socks SSR 机场使用教程](https://freepac.siterubix.com/just-my-socks-ssr-%e6%9c%ba%e5%9c%ba%e4%bd%bf%e7%94%a8%e6%95%99%e7%a8%8b/)

## 一、Just My Socks 介绍

[Just My Socks官网](https://justmysocks3.net/members/aff.php?aff=4355)

Just My Socks 是搬瓦工官方出品的 ss 加速器，品质有保障！！！最低价格 $2.88 一个月，每月流量 100GB，提供多个域名供连接，并且保证可用，IP被封自动更换IP，不需要任何操作，也不需要其它费用。全部都是美西 CN2 GIA 线路，速度很快很稳定。现在 [Just My Socks](https://justmysocks3.net/members/aff.php?aff=4355) 已支持**支付宝**支付

**如果你就只想加速上个网，又担心购买 VPS 之后 IP 被墙、端口被封很麻烦，对折腾 VPS 什么的很苦恼，强烈推荐你入手，省心省时省力。**

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130427150-392207424.png)

**Just My Socks 优势：**

1. 搬瓦工（BandwagonHost）出品，值得信赖，靠谱，**不会跑路。**
2. 免去个人搭建代理流程，降低科*上网门槛，更适合 **初级/小白用户**。
3. 全部采用CN2 GIA/CN2国际精品线路，**速度给力。**
4. 提供8个 IP，后台自动检测 ，被墙自动更换，保证可以用，**省事省心**。

如果你是租 VPS 服务器自己搭 (ti) 子，但是又频繁被封 IP，那这个方案是很好的方案。

因为有些地区运营商的原因频繁封 IP ，不管用哪家 VPS 都一样，基本上无解，用这个方法的话确实省事很多。



## 二、Just My Socks 注册

点击打开 [**Just My Socks 官网**]([Just My Socks官网](https://justmysocks3.net/members/aff.php?aff=4355)
)

先选择语言为中文，然后点击 **Browse ALL**

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130445606-911204348.png)

 

**根据自己的需求选择套餐**

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130447781-462919830.png)

 

**点击 购买， 进入结账页面** 

选择付款方式，月付是 $2.88 ，包年或者季度付会便宜一点。

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130450357-392565104.png)

 

输入 **[Just My Socks 优惠码]([Just My Socks官网](https://justmysocks3.net/members/aff.php?aff=4355)
)** （**JMS9272283**） 点击检验代码   可享受 5.2% 的折扣

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130454544-1669234536.png)

 

**然后点击 CheckOut 进行支付，这时候会让你填写一些基本信息，注册账号：**

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130457916-784249832.png)

**勾选同意协议，完成订购即可**

如果你点击完成订购一直无法跳转，是因为页面加载了 Google 验证，你可以开启网络代理刷新页面完成验证即可。

如果没有代理则先注册账号完成人机验证，再购买即可。

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130500673-1917474686.png)

购买完成在 **My Services**下面 可以看到shadowsocks 的**端口，密码和 IP 等信息**（一共8个IP）

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130502819-187994.png)

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130508888-1087718474.png)

 

## 三、Just My Socks 使用

just my socks 怎么用呢！其实就是用 SS  客户端连接

各种客户端版本下载地址：[各版本SS客户端官方下载地址](https://github.com/xiaoming2028/kexueshangwang/releases)

以Windows为例：

端口和加密方式等信息对应填写**（如果客户端有下图中协议和混淆选项，则协议项选择 origin，混淆项 plain，没有则不用管）**

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130525596-1521676809.png)

 

填写完点击确定

在任务栏找到小飞机 并 **右键开启代理**  （PAC为部分流量走代理，全局为所有流量走代理）

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130528089-83987341.png)

连接成功

测试一下

![](https://img2018.cnblogs.com/blog/1765496/202002/1765496-20200218130530870-1337906729.png)
